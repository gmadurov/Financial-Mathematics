
from math import sqrt

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from numpy.linalg import inv


DF = pd.read_csv('Assignment3-data.csv', delimiter=';')
AR = np.array(DF)

def inital_W(C):
    '''finds the initial weight matrix W, given a covariance matrix C'''
    ones = np.ones((len(C), 1))
    W = np.transpose(np.matmul(np.transpose(ones), inv(C)) /
                     np.matmul((np.matmul(np.transpose(ones), inv(C))),    ones))
    return W


def getMin_μσ2(μ, C, show=True):
    '''gets the minimum value of μ and σ**2 for a given expected return matrix μ\n
    and a covariance matrix C, if show is true function returns a string'''
    W = inital_W(C)
    σ2_min = np.matmul(np.matmul(np.transpose(W), C), W)
    μ_min = np.matmul(np.transpose(W), μ)
    if show:
        return f'μ_min  = {μ_min[0][0]}  \nσ2_min = { σ2_min[0][0]}'
    return μ_min[0][0], σ2_min[0][0]


def get_μσ2(μ, C, W, show=True):
    '''gets the value of μ and σ**2, for a given expected return matrix μ\n and a covariance matrix C, and a weight matrix W.\nif show is true function returns a string'''
    σ2 = np.matmul(np.matmul(np.transpose(W), C), W)
    μ = np.matmul(np.transpose(W), μ)
    if show:
        return f'μ  = {μ[0][0]}  \n σ2 = { σ2[0][0]}'
    return μ[0][0], σ2[0][0]

def Markowitz(muval, μ, C):
    '''Solve the Markowitz problem given a value specific value of return- muval
    the excpected return vector (μ) and the covariance matrix (C)'''
    if muval == 0:
        muval = getMin_μσ2(μ, C, False)[0]
    # set up vector for all the weights on the Right Hand Side (RHS)
    RHS = np.array([[0] for i in range(len(μ))])
    # adds the value of μ and 1 to the RHS vector (forming the last 2 constraints)
    RHS = np.vstack((RHS, np.array([[muval], [1]])))
    # the following gets to the covariance matrix and adds the labmda variable coefficients
    # to create the Left Hand Side of the equation
    LHS = np.append(C, -μ, axis=1)
    LHS = np.append(LHS, -np.ones((len(C), 1)), axis=1)
    LHS = np.vstack((LHS, np.append(μ, [0, 0])))
    LHS = np.vstack((LHS, np.append(np.ones(len(C)), [0, 0])))
    # this line solves it and returns (ONLY) the values of the weights
    # return pd.DataFrame(LHS), pd.DataFrame(RHS)
    return (np.matmul(inv(LHS), RHS)[:len(μ)])

def plotEfficientFrontier(μ, C, lb=-1, ub=2, show=True):
    varlist = []
    mewplotlist = []
    colour = []
    for i in range(lb*1000, ub*1000):  # change this range to what you want to show
        i /= 1000
        W = Markowitz(i, μ, C)
        if i < 0:
            colour.append('red')
        elif i > 0 and i <= 1:
            colour.append('green')
        elif i > 1:
            colour.append('blue')
        else:
            colour.append('none')
        mewplot = np.matmul(np.transpose(W), μ)[0][0]
        sig2 = sqrt(np.matmul(np.matmul(np.transpose(W), C), (W))[0][0])
        mewplotlist.append(mewplot)
        varlist.append(sig2)
    if show:
        plt.title('Efficient Frontier')
        plt.xlabel('σ (volatility)')
        plt.ylabel('μ (return)')
        plt.scatter(varlist, mewplotlist, c=colour, s=2, )
        plt.show()
        return
    return list(zip(varlist, mewplotlist))

DF_R = pd.DataFrame()
for col in DF.columns[1:]:
    # DF_R.loc[0, 'r_'+col] = 0 # taken out because you only use sum of 1 to T
    for i in range(1, len(DF[col])):
        try:
            DF_R.loc[i, 'r_'+col] = ((DF.loc[i, col] -
                                     DF.loc[i-1, col]) / DF.loc[i-1, col])
        except IndexError:
            print(f'error in {i}, in {col}')
R_array = np.array(DF_R)
# R_array
μ = np.array([[i] for i in np.sum(R_array, axis=0)])
C = np.cov(R_array, rowvar=False)*365
# C, μ
def two_fund_theorem_from_points(μ1, σ1, μ2, σ2, covMinMarket=0, show=True, fig=None):
    # two_fund_theorem_from_points(market_μ, market_σ, μ_min, σ_min, row, show=False, fig=fig)
    if not fig:
        fig = plt.figure(figsize=(6, 5))
    if μ1 < μ2 and σ1 < σ2:
        μ1, σ1, μ2, σ2 = μ2, σ2, μ1, σ1
    μpoints, σpoints, colours = [], [], []
    for w in range(-10, 151):
        w /= 100
        if w < 0:
            colours.append('red')
        elif w > 0 and w <= 1:
            colours.append('green')
        elif w > 1:
            colours.append('blue')
        else:
            colours.append('none')
        μv = w*μ1 + (1-w)*μ2
        σv = sqrt((w**2*σ1**2)+(2*w*(1-w)*σ1*σ2*covMinMarket) + ((1-w)**2*σ2**2))
        μpoints.append(μv)
        σpoints.append(σv)
    axarr = fig.add_subplot(1, 1, 1)
    plt.plot(σpoints, μpoints)
    if show:
        plt.title('Efficient Frontier(two fund theorem)')
        plt.xlabel('σ (volatility)')
        plt.ylabel('μ (return)')
        plt.scatter((σ1), μ1,  c='b')
        plt.scatter((σ2), μ2,  c='r')
        plt.show()
        return
    return σpoints, μpoints

def RiskFreeAssest(μ, C, rf):
    dic = {}
    for (σc, μc) in plotEfficientFrontier(μ, C, show=False):
        dic[((μc-rf)/σc)] = (μc)
    W_market = Markowitz(dic[max(dic)], μ, C)
    W_min = inital_W(C)
    market_μ, σ2p1 = get_μσ2(μ, C, W_market, False)
    market_σ = sqrt(σ2p1)

    μ_min, σ_min = get_μσ2(μ, C, W_min, False)
    σ_min = sqrt(σ_min)
    covMinMarket = np.matmul(np.matmul(np.transpose(W_min), C), W_market)
        # this is the line from the rf point to the market portfolio
    # capitalmarket line
    fig = plt.figure(figsize=(10, 8))
    # usign the 2 fund theorem to plot the efficeint frontier
    val = two_fund_theorem_from_points(
        μ_min, σ_min, market_μ, market_σ,  covMinMarket, show=False, fig=fig)
    sigma = np.linspace(0, max(val[0]))
    mew = rf+sigma*(market_μ-rf)/market_σ
    plt.title('Efficient Frontier(Risk free asset)')
    plt.xlabel('σ (volatility)')
    plt.ylabel('μ (return)')
    plt.plot(sigma, mew, c='black', linestyle='dashed')
    plt.scatter((σ_min), μ_min,  c='red')
    plt.scatter((market_σ), market_μ,  c='green', s=30)
    plt.show()
    print('Risk free asset weights ', pd.DataFrame(np.transpose(W_min)).to_latex(), pd.DataFrame(np.transpose(W_market)).to_latex())


RiskFreeAssest(μ, C, 1/100)

# Part 2.4
# getting rid of HEX
R_array2 = R_array[:, :4]
μ2 = np.array([[i] for i in np.sum(R_array2, axis=0)])
C2 = np.cov(R_array2, rowvar=False)*365

# plotEfficientFrontier(μ2, C2)

RiskFreeAssest(μ2, C2, 1/100)